#include "myheder.h"

typedef struct score {
	int kor, eng, mat;
	double avg;
}score;

int main()
{
	score s[3] = { 
		{70,70,70},
		{80,80,80}, 
		{90,90,90}};

	score* p = s;

	s[1].avg = (s[1].kor + s[1].eng + s[1].mat) / 3.0;
	printf("2��° ���� �����? %.2f\n", s[1].avg);




	return 0;
}