#include "myheder.h"

typedef struct score {
	int kor, eng, mat;
	double avg;
}score;

int main() {
	//printf("%d\n", randInt(100, 200));
	//printf("%d\n", randInt(1, 100));
	//printf("%d\n", randInt(900, 999));
	//printf("%d\n", randInt(500, 555));

	score sco = { 70, 80, 90 };
	score* p=&sco;

	sco.avg = sco.kor + sco.eng + sco.mat;
	printf("%f\n", sco.avg);

	p->avg = (p->kor + p->eng + p->mat) / 3.0;
	printf("%f\n", p->avg);


	return 0;
}